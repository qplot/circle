<?php 

function circle_preprocess_node(&$var) {
//  kpr($var);
}

function circle_preprocess_html(&$var) {
  $var['path'] = base_path() . drupal_get_path('theme', 'circle') . "/images/";
}

function circle_preprocess_block(&$var) {
  // prepare courses
        $var['courses'] = array(
          0 => array(
            'title' => 'Academic Dean',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Lee Baker', // instructor
                'pic_url' => 'lee-baker.120.120.png', // pic
                'class' => 'ciradmin',
             ),
            ),
          ),
          1 => array(
            'title' => 'Academic Advisor',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Susan Alberts', // instructor
                'pic_url' => 'susan-alberts.120.120.jpg', // pic
                'class' => 'ciradmin',
             ),
            ),
          ),
          2 => array(
            'title' => 'Math I',
            'building' => 'Math Hall',
            'instructors' => array(
              0 => array(
                'name' => 'David McClay, PhD', // instructor
                'pic_url' => 'david-mcclay.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          /*3 => array(
            'title' => 'Biology 101',
            'building' => 'Science Hall',
            'instructors' => array(
              0 => array(
                'name' => 'Guo Juin Hong, PhD', // instructor
                'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          4 => array(
            'title' => 'English 101',
            'building' => 'English Hall',
            'instructors' => array(
              0 => array(
                'name' => 'Michael Moses, PhD', // instructor
                'pic_url' => 'michael-moses.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          5 => array(
            'title' => 'Calculus 101',
            'building' => 'Math Hall',
            'instructors' => array(
              0 => array(
                'name' => 'David McClay, PhD', // instructor
                'pic_url' => 'david-mcclay.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          6 => array(
            'title' => 'US History',
            'building' => 'Carr Building',
            'instructors' => array(
              0 => array(
                'name' => 'Huntington Willard, PhD', // instructor
                'pic_url' => 'huntington-willard.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          7 => array(
             'title' => 'Chemisty I',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           8 => array(
             'title' => 'Calculus 101',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           9 => array(
             'title' => 'English 101',
             'building' => 'English Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Michael Moses, PhD', // instructor
                 'pic_url' => 'michael-moses.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           10 => array(
             'title' => 'Biology 101',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           11 => array(
             'title' => 'US History',
             'building' => 'Carr Building',
             'instructors' => array(
               0 => array(
                 'name' => 'Fang Jin, PhD', // instructor
                 'pic_url' => 'fang-jin.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           12 => array(
             'title' => 'Chemisty I',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           13 => array(
             'title' => 'Math II',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           14 => array(
             'title' => 'Calculus 101',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ), 
           15 => array(
            'title' => 'Pegram Hall Resident Assistant',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Audrey Kang', // instructor
                'pic_url' => 'audrey-kang.120.120.png', // pic
                'class' => 'ciradmin',
             ),
            ),
          ), */


        );



//  $var['abc'] = 1;
//  dsm($var['block']);
  // defines $url
  $url = $_SERVER['REQUEST_URI'];
  // dsm(current_path());
  // see if URL contains strong
  if (strpos($url, 'circles/50/small')) {
    // looks for node--circle.tpl.php in your theme directory
    $var['theme_hook_suggestion'] = 'block__50__small';
  }
  if (strpos($url, 'circles/50/hover')) {
    $var['theme_hook_suggestion'] = 'block__50__hover';
  }
  if (strpos($url, 'circles/50/0')) {
    $var['theme_hook_suggestion'] = 'block__50__0';
  }
  if (strpos($url, 'circles/50/1')) {
    $var['theme_hook_suggestion'] = 'block__50__1';
  }
  if (strpos($url, 'circles/50/2')) {
    $var['theme_hook_suggestion'] = 'block__50__2';
  }
  if (strpos($url, 'circles/50/3')) {
    $var['theme_hook_suggestion'] = 'block__50__3';
  }
  if (strpos($url, 'circles/50/4')) {
    $var['theme_hook_suggestion'] = 'block__50__4';
  }
  if (strpos($url, 'circles/50/5')) {
    $var['theme_hook_suggestion'] = 'block__50__5';
  }
  if (strpos($url, 'circles/50/6')) {
    $var['theme_hook_suggestion'] = 'block__50__6';
  }
  if (strpos($url, 'circles/50/7')) {
    $var['theme_hook_suggestion'] = 'block__50__7';
  }
  if (strpos($url, 'circles/50/8')) {
    $var['theme_hook_suggestion'] = 'block__50__8';
  }
  if (strpos($url, 'circles/50/9')) {
    $var['theme_hook_suggestion'] = 'block__50__9';
  }
  if (strpos($url, 'circles/50/10')) {
    $var['theme_hook_suggestion'] = 'block__50__10';
  }
  if (strpos($url, 'circles/50/11')) {
    $var['theme_hook_suggestion'] = 'block__50__11';
  }
  if (strpos($url, 'circles/50/12')) {
    $var['theme_hook_suggestion'] = 'block__50__12';
  }
  if (strpos($url, 'circles/50/13')) {
    $var['theme_hook_suggestion'] = 'block__50__13';
  }
  if (strpos($url, 'circles/50/14')) {
    $var['theme_hook_suggestion'] = 'block__50__14';
  }
  if (strpos($url, 'circles/50/15')) {
    $var['theme_hook_suggestion'] = 'block__50__15';
  }
  if (strpos($url, 'circles/50/sub')) {
    $var['theme_hook_suggestion'] = 'block__50__sub';
  }

}

function circle_preprocess_views_view(&$var) {
//	kpr($var);
//	print $var['display_id'];
}

