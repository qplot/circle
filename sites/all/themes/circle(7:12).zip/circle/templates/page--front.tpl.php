<?php
/**
 * @file
 * Bartik's theme implementation to display a single Drupal page.
 *
 * The doctype, html, head and body tags are not in this template. Instead they
 * can be found in the html.tpl.php template normally located in the
 * modules/system directory.
 *
 * Available variables:
 *
 * General utility variables:
 * - $base_path: The base URL path of the Drupal installation. At the very
 *   least, this will always default to /.
 * - $directory: The directory the template is located in, e.g. modules/system
 *   or themes/bartik.
 * - $is_front: TRUE if the current page is the front page.
 * - $logged_in: TRUE if the user is registered and signed in.
 * - $is_admin: TRUE if the user has permission to access administration pages.
 *
 * Site identity:
 * - $front_page: The URL of the front page. Use this instead of $base_path,
 *   when linking to the front page. This includes the language domain or
 *   prefix.
 * - $logo: The path to the logo image, as defined in theme configuration.
 * - $site_name: The name of the site, empty when display has been disabled
 *   in theme settings.
 * - $site_slogan: The slogan of the site, empty when display has been disabled
 *   in theme settings.
 * - $hide_site_name: TRUE if the site name has been toggled off on the theme
 *   settings page. If hidden, the "element-invisible" class is added to make
 *   the site name visually hidden, but still accessible.
 * - $hide_site_slogan: TRUE if the site slogan has been toggled off on the
 *   theme settings page. If hidden, the "element-invisible" class is added to
 *   make the site slogan visually hidden, but still accessible.
 *
 * Navigation:
 * - $main_menu (array): An array containing the Main menu links for the
 *   site, if they have been configured.
 * - $secondary_menu (array): An array containing the Secondary menu links for
 *   the site, if they have been configured.
 * - $breadcrumb: The breadcrumb trail for the current page.
 *
 * Page content (in order of occurrence in the default page.tpl.php):
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title: The page title, for use in the actual HTML content.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 * - $messages: HTML for status and error messages. Should be displayed
 *   prominently.
 * - $tabs (array): Tabs linking to any sub-pages beneath the current page
 *   (e.g., the view and edit tabs when displaying a node).
 * - $action_links (array): Actions local to the page, such as 'Add menu' on the
 *   menu administration interface.
 * - $feed_icons: A string of all feed icons for the current page.
 * - $node: The node object, if there is an automatically-loaded node
 *   associated with the page, and the node ID is the second argument
 *   in the page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - $page['header']: Items for the header region.
 * - $page['featured']: Items for the featured region.
 * - $page['highlighted']: Items for the highlighted content region.
 * - $page['help']: Dynamic help text, mostly for admin pages.
 * - $page['content']: The main content of the current page.
 * - $page['sidebar_first']: Items for the first sidebar.
 * - $page['triptych_first']: Items for the first triptych.
 * - $page['triptych_middle']: Items for the middle triptych.
 * - $page['triptych_last']: Items for the last triptych.
 * - $page['footer_firstcolumn']: Items for the first footer column.
 * - $page['footer_secondcolumn']: Items for the second footer column.
 * - $page['footer_thirdcolumn']: Items for the third footer column.
 * - $page['footer_fourthcolumn']: Items for the fourth footer column.
 * - $page['footer']: Items for the footer region.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 * @see template_process()
 * @see bartik_process_page()
 * @see html.tpl.php
 */
?>
<div id="page-wrapper"><div id="page">

  <div id="header" class="<?php print $secondary_menu ? 'with-secondary-menu': 'without-secondary-menu'; ?>"><div class="section clearfix">

    <?php if ($logo): ?>
      <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
      </a>
    <?php endif; ?>

    <?php if ($site_name || $site_slogan): ?>
      <div id="name-and-slogan"<?php if ($hide_site_name && $hide_site_slogan) { print ' class="element-invisible"'; } ?>>

        <?php if ($site_name): ?>
          <?php if ($title): ?>
            <div id="site-name"<?php if ($hide_site_name) { print ' class="element-invisible"'; } ?>>
              <strong>
                <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
              </strong>
            </div>
          <?php else: /* Use h1 when the content title is empty */ ?>
            <h1 id="site-name"<?php if ($hide_site_name) { print ' class="element-invisible"'; } ?>>
              <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
            </h1>
          <?php endif; ?>
        <?php endif; ?>

        <?php if ($site_slogan): ?>
          <div id="site-slogan"<?php if ($hide_site_slogan) { print ' class="element-invisible"'; } ?>>
            <?php print $site_slogan; ?>
          </div>
        <?php endif; ?>

      </div> <!-- /#name-and-slogan -->
    <?php endif; ?>

    <?php print render($page['header']); ?>

    <?php if ($main_menu): ?>
      <div id="main-menu" class="navigation">
        <?php print theme('links__system_main_menu', array(
          'links' => $main_menu,
          'attributes' => array(
            'id' => 'main-menu-links',
            'class' => array('links', 'clearfix'),
          ),
          'heading' => array(
            'text' => t('Main menu'),
            'level' => 'h2',
            'class' => array('element-invisible'),
          ),
        )); ?>
      </div> <!-- /#main-menu -->
    <?php endif; ?>

    <?php if ($secondary_menu): ?>
      <div id="secondary-menu" class="navigation">
        <?php print theme('links__system_secondary_menu', array(
          'links' => $secondary_menu,
          'attributes' => array(
            'id' => 'secondary-menu-links',
            'class' => array('links', 'inline', 'clearfix'),
          ),
          'heading' => array(
            'text' => t('Secondary menu'),
            'level' => 'h2',
            'class' => array('element-invisible'),
          ),
        )); ?>
      </div> <!-- /#secondary-menu -->
    <?php endif; ?>

  </div></div> <!-- /.section, /#header -->

  <?php if ($messages): ?>
    <div id="messages"><div class="section clearfix">
      <?php print $messages; ?>
    </div></div> <!-- /.section, /#messages -->
  <?php endif; ?>

  <?php if ($page['featured']): ?>
    <div id="featured"><div class="section clearfix">
      <?php print render($page['featured']); ?>
    </div></div> <!-- /.section, /#featured -->
  <?php endif; ?>

  <div id="main-wrapper" class="clearfix"><div id="main" class="clearfix">

   <!--  <?php if ($breadcrumb): ?>
      <div id="breadcrumb"><?php print $breadcrumb; ?></div>
    <?php endif; ?> hide breadcrumbs -->

    <?php if ($page['sidebar_first']): ?>
      <div id="sidebar-first" class="column sidebar"><div class="section">
        <?php print render($page['sidebar_first']); ?>
      </div></div> <!-- /.section, /#sidebar-first -->
    <?php endif; ?>

    <div id="content" class="column"><div class="section">
      <?php if ($page['highlighted']): ?><div id="highlighted"><?php print render($page['highlighted']); ?></div><?php endif; ?>
      <a id="main-content"></a>
      <?php print render($title_prefix); ?>
      <?php if ($title): ?>
        <h1 class="title" id="page-title">
          <?php print $title; ?>
        </h1>
      <?php endif; ?>
      <?php print render($title_suffix); ?>
      <?php if ($tabs): ?>
        <div class="tabs">
          <?php print render($tabs); ?>
        </div>
      <?php endif; ?>
      <?php print render($page['help']); ?>
      <?php if ($action_links): ?>
        <ul class="action-links">
          <?php print render($action_links); ?>
        </ul>
      <?php endif; ?>
      

      <div id="wrapper">
<h1>Advising Circle for Jane Q. Student</h1>
<?php 
  $path = base_path() . drupal_get_path('theme', 'circle') . "/images/";
 ?>
<div id="container">
    <div id="center">
		<a class="various" href="#student"><img src="<?=$path;?>student.png" /></a>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile01"><img src="<?=$path;?>lee-baker.120.150.jpg" border="0" /></a></div>
		<div class="name">Lee Baker, PhD</div>
		<div class="title">Academic Dean</div>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile02"><img src="<?=$path;?>susan-alberts.120.120.jpg" border="0" /></a></div>
		<div class="name">Susan Alberts, PhD</div>
		<div class="title">Academic Advisor</div>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile03"><img src="<?=$path;?>david-mcclay.120.120.jpg" border="0" /></a></div>
		<div class="name">David McClay, PhD</div>
		<div class="title">Instructor, BIOLOGY 119.02D</div>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile04"><img src="<?=$path;?>hargrove.120.120.jpg" border="0" /></a></div>
		<div class="name">Amanda Hargrove, PhD</div>
		<div class="title">Instructor, CHEM 166.01</div>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile05"><img src="<?=$path;?>michael-moses.120.120.jpg" border="0" /></a></div>
		<div class="name">Michael Moses, PhD</div>
		<div class="title">Instructor, ENGLISH 103S.01</div>
	</div>
    <div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile06"><img src="<?=$path;?>guo-juin-hong.120.120.jpg" border="0" /></a></div>
		<div class="name">Guo-Juin Hong, PhD</div>
		<div class="title">Instructor, AMES 89S.03</div>
	</div>
	<div class="fieldc">
		<div class="advisor-thumb"><a class="various" href="#profile07"><img src="<?=$path;?>audrey-kang.120.120.png" border="0" /></a></div>
		<div class="name">Audrey Kang</div>
		<div class="title">Pegram Hall Resident Assistant</div>
	</div>
</div>

<!-- inline elements -->
<div id="student" class="profile" style="display:none;width:100%;">
	<img src="<?=$path?>/images/student.png" />
	<h2>Jane Q. Student</h2>
	<h3>Freshman</h3>
	<p><strong>Academic Dean:</strong> Lee Baker, PhD</p>
	<p><strong>Academic Advisor:</strong> Susan Alberts, PhD</p>
	<h4>Fall 2013 Course Load:</h4>
	<ul>
	  <li>BIOLOGY 119.02D <em>CELL &amp; DEVELOPMENTAL BIOLOGY</em> - David McClay, PhD<br />
	  TuTh 4:40PM - 5:55PM, Friedl Bdg 216</li>
	  <li>CHEM 166.01 <em>PHYSICAL CHEMISTRY</em> - Amy Bejsovec, PhD<br />
	  MW 8:30AM - 9:45AM, French Science 2231</li>
	  <li>ENGLISH 103S.01 <em>INTRO TO WRITING SHORT STORIES</em> - Michael Valdez Moses, PhD<br />
	  Tu 10:05AM - 12:35PM, Social Sciences 107</li>
	  <li>AMES 89S.03 <em>FIRST-YEAR SEMINAR (TOP)</em> - Guo-Juin Hong, PhD<br />
	  W 1:40PM - 4:10PM, Nasher 119</li>
	</ul>
	<h4>Fall 2013 Housing:</h4>
	<ul>
	  <li>Pegram Residence Hall (Neighborhood 1)</li>
	  <li>Audrey Kang, Resident Assistant</li>
	</ul>
</div>

<div id="profile01" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>lee-baker.240.351.jpg" />
	<h2>Lee Baker, PhD</h2>
	<h3>Academic Advisor</h3>
	<h4>Professor of Cultural Anthropology</h4>
	<p>
		Lee D. Baker is Dean of Academic Affairs of Trinity College of Arts and Sciences, Associate Vice Provost for Undergraduate Education, and Professor of Cultural Anthropology, Sociology, and African and African American Studies at Duke University. He received his B.S. from Portland State University and doctorate in anthropology from Temple University. He has been a resident fellow at Harvard's W.E.B. Du Bois Institute, the Smithsonian's National Museum of American History, Johns Hopkins's Institute for Global Studies, The University of Ghana-Legon, the American Philosophical Society, and the National Humanities Center. His books include From Savage to Negro: Anthropology and the Construction of Race (<a href="https://scholars-staging.oit.duke.edu/display/per8194252">more...</a>)
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> 114 Allen, Durham, NC 27708-0042</li>
		<li><strong>Mailing:</strong> Box 90042, Durham, NC 27708-0042</li>
		<li><strong>Phone:</strong> (919) 684-3465</li>
		<li><strong>Email:</strong> <a href="mailto:ldbaker@duke.edu">ldbaker@duke.edu</a></li>
	</ul>
</div>

<div id="profile02" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>susan-alberts.260.260.jpg" />
	<h2>Susan Alberts, PhD</h2>
	<h3>Academic Advisor</h3>
	<h4>Professor of Biology</h4>
	<p>
		
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> 130 Science Drive, Rm 137, Duke Box 90338, Durham, NC 27708</li>
		<li><strong>Mailing:</strong> Box 90338, Durham, NC 27708-0338</li>
		<li><strong>Phone:</strong> (919) 660-7272</li>
		<li><strong>Email:</strong> <a href="mailto:alberts@duke.edu">alberts@duke.edu</a></li>
	</ul>
</div>

<div id="profile03" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>david-mcclay.260.260.jpg" />
	<h2>David McClay, PhD</h2>
	<h3>Instructor, BIOLOGY 119.02D</h3>
	<h4>Arthur S. Pearse Professor of Biology in Trinity College of Arts and Sciences</h4>
	<p>
		We ask how the embryo works. Prior to morphogenesis the embryo specifies each cell through transcriptional regulation and signaling. Our research builds gene regulatory networks to understand how that early specification works. We then ask how this specification programs cells for their morphogenetic movements at gastrulation, and how the cells deploy patterning information. Current projects examine 1) novel signal transduction mechanisms that establish and maintain embryonic boundaries mold the embryo at gastrulation; 2) specification of primary mesenchyme cells in such a way that they are prepared to execute an epithelial-mesenchymal transition, and then study mechanistically the regulation of that transition (<a href="https://scholars-staging.oit.duke.edu/display/per0577042">more...</a>)
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> 4102 French Science Center, Science Dr., Durham, NC 27708</li>
		<li><strong>Mailing:</strong> Box 90338, Department of Biology, Durham, NC 27708-1000</li>
		<li><strong>Phone:</strong> (919) 613-8188</li>
		<li><strong>Email:</strong> <a href="mailto:dmcclay@duke.edu">dmcclay@duke.edu</a></li>
	</ul>
</div>

<div id="profile04" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>hargrove.jpg" />
	<h2>Amanda Hargrove, PhD</h2>
	<h3>Instructor, CHEM 166.01</h3>
	<h4>Scholar in Residence</h4>
	<!--<p>
		The Hargrove lab will harness the unique properties of small organic molecules to study the structure, function and therapeutic potential of long noncoding RNAs (lncRNAs). The discovery of these fascinating biomolecules has caused a paradigm shift in molecular biology and speculation as to their role as the master drivers of diseases such as cancer. At the same time very little is known about their structure and function, leading some to call the field a veritable “wild West.” Small molecules are the perfect tools for such exploration, and the Hargrove lab will work at the interface of chemistry and biology, employing (<a href="https://scholars-staging.oit.duke.edu/">more...</a>)
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> Rm. 4312 Ffsc, Dept. of Biology, Durham, NC 27708</li>
		<li><strong>Mailing:</strong> Box 90338, Dept. of Biology, Durham, NC 27708-0338</li>
		<li><strong>Phone:</strong> (919) 613-8162</li>
		<li><strong>Email:</strong> <a href="mailto:bejsovec@duke.edu">bejsovec@duke.edu</a></li>
	</ul>-->
</div>

<div id="profile05" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>michael-moses.jpg" />
	<h2>Michael Moses, PhD</h2>
	<h3>Instructor, ENGLISH 103S.01</h3>
	<h4>Associate Professor with Tenure</h4>
	<p>
		Michael Valdez Moses grew up in Los Angeles and was educated at Harvard, New College, Oxford, and the University of Virginia. He is the author of <i>The Novel and the Globalization of Culture</i> (Oxford UP, 1995), and has edited several collections of critical essays including <i>The Writings of J. M. Coetzee</i> (Duke UP, 1994), <i>Modernism and Colonialism:  British and Irish Literature, 1900-1939</i> (Duke UP, 2007), and <i>Modernism and Cinema,</i> (Edinburgh UP, 2010).  His articles and reviews have appeared in <i>Modernism/Modernity</I>, <i>Kenyon Review</i>, <i> Modernist Cultures</I>, <i>Latin American Literary Review</i>, <i>South Atlantic Quarterly</i>, <i>Modern Fiction Studies</i>, <i>Literary Imagination</i>, <i>Journal of Literary Studies</i> (<a href="https://scholars-staging.oit.duke.edu/display/per5145252">more...</a>)
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> 319 Allen Bldg, Durham, NC 27708</li>
		<li><strong>Mailing:</strong> Box 90015, Durham, NC 27708-0015</li>
		<li><strong>Phone:</strong> (919) 684-8880</li>
		<li><strong>Email:</strong> <a href="mailto:mmoses@duke.edu">mmoses@duke.edu</a></li>
	</ul>
</div>

<div id="profile06" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>guo-juin-hong.jpg" />
	<h2>Guo-Juin Hong, PhD</h2>
	<h3>Instructor, AMES 89S.01</h3>
	<h4>Associate Professor of Asian and Middle Eastern Studies</h4>
	<p>
		Film historiography, film theory, postcolonial theory and theories of culture and globalization; film and other media of Taiwan, Hong Kong and China
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Office:</strong> 2204 Erwin Road, Room 220, Durham, NC 27708</li>
		<li><strong>Mailing:</strong> Box 90414, Durham, NC 27708-0414</li>
		<li><strong>Phone:</strong> (919) 660-4396</li>
		<li><strong>Email:</strong> <a href="mailto:jghong@duke.edu">jghong@duke.edu</a></li>
	</ul>
</div>

<div id="profile07" class="profile" style="display:none;width:100%;">
	<img src="<?=$path;?>audrey-kang.260.260.jpg" />
	<h2>Audrey Kang</h2>
	<h3>Pegram Hall Resident Assistant</h3>
	<p>
		
	</p>
	<h4>Contact Information</h4>
	<ul>
		<li><strong>Mailing:</strong> Box 90414, Durham, NC 27708-0414</li>
		<li><strong>Phone:</strong> (919) 660-4396</li>
		<li><strong>Email:</strong> <a href="mailto:jghong@duke.edu">jghong@duke.edu</a></li>
	</ul>
</div>
</div>


     <!--  <?php print $feed_icons; ?> -->
    </div></div> <!-- /.section, /#content -->

    <?php if ($page['sidebar_second']): ?>
      <div id="sidebar-second" class="column sidebar"><div class="section">
        <?php print render($page['sidebar_second']); ?>
      </div></div> <!-- /.section, /#sidebar-second -->
    <?php endif; ?>

  </div></div> <!-- /#main, /#main-wrapper -->

  <?php if ($page['triptych_first'] || $page['triptych_middle'] || $page['triptych_last']): ?>
    <div id="triptych-wrapper"><div id="triptych" class="clearfix">
      <?php print render($page['triptych_first']); ?>
      <?php print render($page['triptych_middle']); ?>
      <?php print render($page['triptych_last']); ?>
    </div></div> <!-- /#triptych, /#triptych-wrapper -->
  <?php endif; ?>

  <div id="footer-wrapper"><div class="section">

    <?php if ($page['footer_firstcolumn'] || $page['footer_secondcolumn'] || $page['footer_thirdcolumn'] || $page['footer_fourthcolumn']): ?>
      <div id="footer-columns" class="clearfix">
        <?php print render($page['footer_firstcolumn']); ?>
        <?php print render($page['footer_secondcolumn']); ?>
        <?php print render($page['footer_thirdcolumn']); ?>
        <?php print render($page['footer_fourthcolumn']); ?>
      </div> <!-- /#footer-columns -->
    <?php endif; ?>

    <?php if ($page['footer']): ?>
      <div id="footer" class="clearfix">
        <?php print render($page['footer']); ?>
      </div> <!-- /#footer -->
    <?php endif; ?>

  </div></div> <!-- /.section, /#footer-wrapper -->

</div></div> <!-- /#page, /#page-wrapper -->
