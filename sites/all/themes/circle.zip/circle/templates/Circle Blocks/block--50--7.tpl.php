<?php 
print "Circles (7 version) <br />"; 
?>

      <?php 
        $path = base_path() . drupal_get_path('theme', 'circle') . "/images/";

        $courses = array(
          0 => array(
            'title' => 'Academic Dean',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Lee Baker', // instructor
                'pic_url' => 'lee-baker.120.120.png', // pic
                'class' => 'ciradmin',
             ),
            ),
          ),
          1 => array(
            'title' => 'Academic Advisor',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Susan Alberts', // instructor
                'pic_url' => 'susan-alberts.120.120.jpg', // pic
                'class' => 'ciradmin',
             ),
            ),
          ),
          2 => array(
            'title' => 'Math I',
            'building' => 'Math Hall',
            'instructors' => array(
              0 => array(
                'name' => 'David McClay, PhD', // instructor
                'pic_url' => 'david-mcclay.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          3 => array(
            'title' => 'Biology 101',
            'building' => 'Science Hall',
            'instructors' => array(
              0 => array(
                'name' => 'Guo Juin Hong, PhD', // instructor
                'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          4 => array(
            'title' => 'English 101',
            'building' => 'English Hall',
            'instructors' => array(
              0 => array(
                'name' => 'Michael Moses, PhD', // instructor
                'pic_url' => 'michael-moses.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          5 => array(
            'title' => 'Calculus 101',
            'building' => 'Math Hall',
            'instructors' => array(
              0 => array(
                'name' => 'David McClay, PhD', // instructor
                'pic_url' => 'david-mcclay.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          6 => array(
            'title' => 'US History',
            'building' => 'Carr Building',
            'instructors' => array(
              0 => array(
                'name' => 'Huntington Willard, PhD', // instructor
                'pic_url' => 'huntington-willard.120.120.jpg', // pic
                'class' => 'cirins',
             ),
            ),
          ),
          /*7 => array(
             'title' => 'Chemisty I',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           8 => array(
             'title' => 'Calculus 101',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           9 => array(
             'title' => 'English 101',
             'building' => 'English Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Michael Moses, PhD', // instructor
                 'pic_url' => 'michael-moses.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           10 => array(
             'title' => 'Biology 101',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           11 => array(
             'title' => 'US History',
             'building' => 'Carr Building',
             'instructors' => array(
               0 => array(
                 'name' => 'Fang Jin, PhD', // instructor
                 'pic_url' => 'fang-jin.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           12 => array(
             'title' => 'Chemisty I',
             'building' => 'Science Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'Guo Juin Hong, PhD', // instructor
                 'pic_url' => 'guo-juin-hong.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           13 => array(
             'title' => 'Math II',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ),
           14 => array(
             'title' => 'Calculus 101',
             'building' => 'Math Hall',
             'instructors' => array(
               0 => array(
                 'name' => 'David McClay, PhD', // instructor
                 'pic_url' => 'david-mcclay.120.120.jpg', // pic
                 'class' => 'cirins',
              ),
             ),
           ), 
           15 => array(
            'title' => 'Pegram Hall Resident Assistant',
            'building' => '',
            'instructors' => array(
              0 => array(
                'name' => 'Audrey Kang', // instructor
                'pic_url' => 'audrey-kang.120.120.png', // pic
                'class' => 'ciradmin',
             ),
            ),
          ), */


        );
        // $abc = "0";
        // $ctitle = $courses[$abc]['title'];
        // $cins = $courses[$abc]['instructors']['0']['name'];
        // $cinsimg = $courses[$abc]['instructors']['0']['pic_url'];
// dpm($courses);

      ?>
    <?php 

       // foreach ($courses as $value) {
       //   # code...
       //  $ctitle = $value['title'];
       //  $cins = $value['instructors']['0']['name'];
       //  $cinsimg = $value['instructors']['0']['pic_url'];
       //  dsm($ctitle);
       //  dsm($cins);
       //  dsm($cinsimg);
       // }

    ?>

<div id="wrapper">
<div id="container">
      <div id="center">
    <a class="various" href="#student"><img src="<?=$path;?>student.png" /></a>
  </div>
    <?php foreach ($courses as $course): ?> <!-- displays circle for each instructor from array -->
      <?php $instructor = &$course['instructors'][0]; //path through array ?>

      <div class="fieldc">
        <div class="advisor-thumb"><a class="various" href="#"><img src="<?=$path;?><?=$instructor['pic_url'];?>" border="0" /></a></div>
        <div class="name"><?=$instructor['name'];?></div> <!-- displays instructor name -->
        <div class="title"><?=$course['title'];?></div> <!-- displays course name -->
      </div>

    <?php endforeach; ?>
</div>
</div>