<?php
  $path = base_path() . drupal_get_path('theme', 'circle') . "/images/";

  // courses_find_instructors2($campus_id = "0592266");
  // $view = views_get_view('roster');
  // $view->execute();
  // // dsm($view->result);

  // // post process the data into our theme format
  // // $courses = array (
  // //   'student_campus_id' => '',
  // //   'student_name',
  // //   'course_name',
  // //   'course_nbr',
  // //   'instructor_name'
  // // );
  // $courses = array();
  // foreach ($view->result as $value) {
  //   $courses[] = array(
  //     'Campus ID' => $value->field_field_roster_campusid['0']['raw']['value'],
  //     'Student Name' => $value->node_title, 
  //     'Course NBR' => $value->field_field_roster_classnbr['0']['raw']['value'],
  //     'Course Name' => $value->node_field_data_field_roster_course_title,
  //     'Instructor Name' => !empty($value->field_field_class_instructor[0]['raw']['value'])?$value->field_field_class_instructor[0]['raw']['value']:'',
  //     'Node ID' => $value->nid,
  //   );
  // }
  // dsm($courses); 
?>
<table class='coursetable'>
  <th>Campus ID</th>
  <th>Full Name</th>
  <th>NBR</th>
  <th>Course Name</th>
  <th>Instructor Name</th>
<?php foreach ($courses as $course) : ?>
  <?php  
    $CampusID = $course['Campus ID'];
    $studentName = $course['Student Name'];
    $CourseNBR = $course['Course NBR'];
    $CourseName = $course['Course Name'];
    $InstructorName = $course['Instructor Name'];
    $NodeID = $course['Node ID'];
  ?>
  <tr>
    <td><a href="160774/<?=$CampusID?>"><?=$CampusID?></a></td>
    <td class="even"><?=$studentName?></td>
    <td><?=$CourseNBR?></td>
    <td class="even"><a href="<?=$NodeID?>"><?=$CourseName?></a></td>
    <td><?=$InstructorName?></td>
  </tr>
<?php endforeach; ?>
</table>



<?php $path = base_path() . drupal_get_path('theme', 'circle') . "/images/"; ?>
<div id="wrapper">
<div id="container">
      <div id="center">
    <a class="various" href="#student"><img src="<?=$path;?>student.png" /></a>
  </div>
    <?php foreach ($courses as $course): ?> <!-- displays circle for each instructor from array -->
      <?php // get info for each course
      $CourseName = $course['Course Name'];
      $InstructorName = $course['Instructor Name']; 
      ?>
        <div class="fieldc">
         <div class="advisor-thumb"><a class="various" href="#"><!-- <img src="<?=$path?>sherwood.120.120.jpg" border="0" /> --></a></div>
          <div class="name"><?=$InstructorName;?></div> <!-- displays instructor name -->
          <div class="title"><?=$CourseName;?></div> <!-- displays course name -->
        </div>
    <?php endforeach; ?>
</div>
</div>









